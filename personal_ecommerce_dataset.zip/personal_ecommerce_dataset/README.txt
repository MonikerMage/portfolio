Name: Jordan Brown
Data source: https://www.kaggle.com/datasets/michealknight/personal-ecommerce-website-ad-cost-and-viewer-count
This data was prepared by the author of website traffic data for an unnamed website from 01/01/2022 to 12/31/2024, and only recognizes a few federal holidays per year(New years, July 4th/US Independence day, Thanksgiving, and Christmas day). I have used it as an example of my data analysis process to make recommendations to stakeholders. I used Microsoft Excel and Microsoft Powerpoint to explore, visualize, and present this data and my findings.

1. Confirmed that data columns in file matches columns in source schema and confirmed understanding of each column.
2. Created duplicate tab of data to work with and labeled original for preservation.
3. Confirmed no duplicates with Excel's Remove Duplicates process.
4. Used Filter to confirm no empty/null cells.
5. Determined that Excel added apostrophes to page_view and ad_spend columns, and used VALUE function to remove the apostrophes.
6. Created a pivot table.
7. Determined that Monday receives the most page views, while Thursday receives the least across all days.
8. We currently spend the most on ads for Tuesday, and the least for Saturday.
9. When considering holidays the numbers change slightly, but since only 4 holidays are recognized per year for a total of 12 in the whole dataset, I do not believe there is enough data to skew observations. It should still be noted that Monday reoccurs the most among those four holidays in the dataset, at 4 times.
10. Created a column chart to visualize ad_spend and page_views at once.
11. Based on the data, there is a trend of page views trailing off from Tuesday through Thursday, and then beginning to increase from Friday through Monday. Ad spending shows a different trend, as we have been spending the most on Tuesdays.
12. With this information, I would recommend we push sales on our website starting on Saturday and continuing through Monday; this will allow us to capitolize on the upswing in digital traffic. It may also be worthwhile to reduce ad spending on Tuesday to reduce costs the day after a sale ends; alternatively those funds could be reallocated to Wednesday or Thursday to better
13. Presented findings in presentation.